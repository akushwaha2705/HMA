from django.contrib.auth.models import User, Group


def create_users_and_groups():
    # Create superuser
    if not User.objects.filter(username='admin').exists():
        User.objects.create_superuser('a', 'admin@example.com', 'a')

    # Create a group
    if not Group.objects.filter(name='AIQ').exists():
        Group.objects.create(name='AIQ')

    if not Group.objects.filter(name='HEA').exists():
        Group.objects.create(name='HEA')

    # Create a user and add to the group
    if not User.objects.filter(username='aiqadmin-xper@hma.com').exists():
        user = User.objects.create_user('aiqadmin-xper@hma.com', 'aiqadmin-xper@hma.com', 'hma12345')
        group = Group.objects.get(name='AIQ')
        group.user_set.add(user)

    if not User.objects.filter(username='heaadmin-xper@hma.com').exists():
        user = User.objects.create_user('heaadmin-xper@hma.com', 'heaadmin-xper@hma.com', 'hma12345')
        group = Group.objects.get(name='HEA')
        group.user_set.add(user)

# Call the function
create_users_and_groups()
