# knowledge-search-poc

## On a new setup, 
1. Create a new folder secure.py
   A. `KEY = "OPENAI_KEY"`

2. Create a new folder knowledge-poc
   A. This should have all PDFs, where we will asks questions to